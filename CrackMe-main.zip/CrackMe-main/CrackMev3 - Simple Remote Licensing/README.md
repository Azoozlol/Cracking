# Introduction
This version of CrackMe uses internet to get the key from the server.

# Walkthrough
Since there is no key stored in local, so we have to crack this manually. Using dnSpy or Ghidra, we learn that the url is defined in the variable section. From here, we can copy and paste the url in web browser to get the license key.
